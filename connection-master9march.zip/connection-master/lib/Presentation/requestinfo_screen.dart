import 'package:connection_app/Presentation/ridescreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Helper/CustomColors.dart';
import 'buttons/CustomButton.dart';

class RequestinfoScreens extends StatefulWidget {
  const RequestinfoScreens({Key? key}) : super(key: key);

  @override
  State<RequestinfoScreens> createState() => _RequestinfoScreensState();
}
class _RequestinfoScreensState extends State<RequestinfoScreens> {
  DateTime date = DateTime(2016, 10, 26);
  DateTime time = DateTime(2016, 5, 10, 22, 35);
  DateTime dateTime = DateTime(2016, 8, 3, 17, 45);

  // This function displays a CupertinoModalPopup with a reasonable fixed height
  // which hosts CupertinoDatePicker.
  void _showDialog(Widget child) {
    showCupertinoModalPopup<void>(
        context: context,
        builder: (BuildContext context) => Container(
          height: 216,
          padding: const EdgeInsets.only(top: 6.0),
          // The Bottom margin is provided to align the popup above the system
          // navigation bar.
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          // Provide a background color for the popup.
          color: CupertinoColors.systemBackground.resolveFrom(context),
          // Use a SafeArea widget to avoid system overlaps.
          child: SafeArea(
            top: false,
            child: child,
          ),
        ));
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height/3,
                      decoration: BoxDecoration(image: DecorationImage(image: AssetImage('assets/images/requestinfoimage.png'),fit:BoxFit.fill)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.dehaze_rounded,color: Colors.white,),
                                SizedBox(width: 250,),
                                Icon(Icons.chat_rounded,color: Colors.white,),
                                SizedBox(width: 25,),
                                Icon(Icons.notifications_active_outlined,color: Colors.white,),
                              ],
                            ),
                          ),
                          Text('Request Info',style: TextStyle(
                              color: CustomColors.primaryColor,fontSize: 25,fontWeight: FontWeight.w500),),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 120.0),
                      child: Container(
                        // height: 600,
                        child: Card(
                          elevation: 4,
                          child: Column(
                            children: [
                              InkWell(
                                onTap: () {
                                  // Navigator.push(context, MaterialPageRoute(builder: (context)=>RideScreen2()));
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 10.0,left: 10,right: 10),
                                  child: Container(
                                    // height: 135,
                                    // width: 420,
                                    child: Center(
                                  child: Column(
                                  children: [
                                  SizedBox(height: 20,),
                                  Material(
                                    // color: splashcolor,
                                    elevation: 1,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width / 1.0,
                                      height: 60,
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'Enter Name';
                                          }
                                          return null;
                                        },
                                        // controller: senderNameController,
                                        decoration: InputDecoration(
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide.none
                                          ),
                                          hintText: " Passenger Name",
                                          prefixIcon: Image.asset('assets/images/usericon.png', scale: 5.1,),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20,),
                                  Material(
                                    // color: splashcolor,
                                    elevation: 1,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width / 1.0,
                                      height: 60,
                                      child: TextFormField(
                                        maxLength: 10,
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return "Phone No.";
                                          }
                                          return null;
                                        },
                                        // controller: senderMobileController,
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide.none
                                          ),
                                          hintText: "Phone No.",
                                          counterText: "",
                                          prefixIcon: Image.asset('assets/images/callicon.png', scale: 5.1, ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20,),
                                    Material(
                                      // color: splashcolor,
                                      elevation: 1,
                                      borderRadius: BorderRadius.circular(10),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width / 1.0,
                                        height: 60,
                                        child: TextFormField(
                                          validator: (value) {
                                            if (value == null || value.isEmpty) {
                                              return 'Enter Name';
                                            }
                                            return null;
                                          },
                                          // controller: senderNameController,
                                          decoration: InputDecoration(
                                            border: const OutlineInputBorder(
                                                borderSide: BorderSide.none
                                            ),
                                            hintText: "Number Of Person",
                                            prefixIcon: Image.asset('assets/images/usericon.png', scale: 5.1, ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 20,),
                                    Material(
                                      // color: splashcolor,
                                      elevation: 1,
                                      borderRadius: BorderRadius.circular(10),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width / 1.0,
                                        height: 60,
                                        child: TextFormField(
                                          validator: (value) {
                                            if (value == null || value.isEmpty) {
                                              return 'Enter Name';
                                            }
                                            return null;
                                          },
                                          // controller: senderNameController,
                                          decoration: InputDecoration(
                                            border: const OutlineInputBorder(
                                                borderSide: BorderSide.none
                                            ),
                                            hintText: "Address",
                                            prefixIcon: Image.asset('assets/images/location.png', scale: 5.1, ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 20,),
                                    // _addressField(context),
                                  Material(
                                    // color: splashcolor,
                                    elevation: 1,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width / 1.0,
                                      height: 60,
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'Please Enter Sender Address';
                                          }
                                          return null;
                                        },
                                        readOnly: true,
                                        // controller: senderAddressCtr,
                                        maxLines: 1,
                                        onTap: (){
                                          // _getLocation1();
                                        },
                                        textInputAction: TextInputAction.next,
                                        decoration: InputDecoration(
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide.none
                                          ),
                                          hintText: "Enter Date",
                                          prefixIcon: Image.asset('assets/images/dateicon.png', scale: 5.5,),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20,),
                                  Material(
                                    // color: splashcolor,
                                    elevation: 1,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width / 1.0,
                                      height: 80,
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'This Field Is Required';
                                          }
                                          return null;
                                        },
                                        // controller: senderfulladdressCtr,
                                        decoration: InputDecoration(
                                          border: const OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                          ),
                                          hintText: "Notes",
                                          prefixIcon: Image.asset('assets/images/editenotes.png',scale: 5.7,
                                           ),
                                        ),
                                      ),
                                    ),
                                  ),
                                    SizedBox(height: 20,),
                                    Material(
                                      // color: splashcolor,
                                      elevation: 1,
                                      borderRadius: BorderRadius.circular(10),
                                      child: Container(
                                        width: MediaQuery.of(context).size.width / 1.0,
                                        height: 60,
                                        child: Row(
                                          // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            Image.asset("assets/images/carusr.png",height: 30,width: 30,),
                                            Text('Sharing:'),
                                            Radio(value: 0, groupValue: 'null', onChanged: (index) {}),
                                            Text('Private'),
                                            Radio(value: 2, groupValue: 'null', onChanged: (index) {}),
                                            Text('Shared'),
                                          ],
                                        )
                                      ),
                                    ),
                                    SizedBox(height: 20,),
                                    Material(
                                      // color: splashcolor,
                                      elevation: 1,
                                      borderRadius: BorderRadius.circular(10),
                                      child: Container(
                                          width: MediaQuery.of(context).size.width / 1.0,
                                          height: 60,
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Expanded(
                                              child: Row(
                                                // mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  Image.asset("assets/images/caricon.png",height: 30,width: 30,),
                                                  Text('Booking:'),
                                                  Radio(value: 1, groupValue: 'null', onChanged: (index) {}),
                                                  Text('Urgent'),
                                                  Radio(value: 2, groupValue: 'null', onChanged: (index) {}),
                                                  Text('Flexible'),
                                                  Radio(value: 2, groupValue: 'null', onChanged: (index) {}),
                                                  // Text('Scheduled'),
                                                ],
                                              ),
                                            ),
                                          ),

                                      ),
                                    ),
                                    SizedBox(height: 10,),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          '${date.month}-${date.day}-${date.year}',
                                          style: const TextStyle(
                                            fontSize: 22.0,
                                          ),
                                        ),
                                      InkWell(
                                        onTap:()
                                        {
                                          _showDialog(
                                            CupertinoDatePicker(
                                              initialDateTime: date,
                                              mode: CupertinoDatePickerMode.date,
                                              use24hFormat: true,
                                              // This is called when the user changes the date.
                                              onDateTimeChanged: (DateTime newDate) {
                                                setState(() => date = newDate);
                                              },
                                            ),
                                          );
                                    },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            color: CustomColors.AppbarColor1
                                          ),
                                          child: Center(child: Text('Date',style: TextStyle(color: Colors.white),)),
                                          height: 30,width: 60,),
                                      ),
                                        // CupertinoButton(
                                        //   // Display a CupertinoDatePicker in date picker mode.
                                        //   onPressed: () => _showDialog(
                                        //     CupertinoDatePicker(
                                        //       initialDateTime: date,
                                        //       mode: CupertinoDatePickerMode.date,
                                        //       use24hFormat: true,
                                        //       // This is called when the user changes the date.
                                        //       onDateTimeChanged: (DateTime newDate) {
                                        //         setState(() => date = newDate);
                                        //       },
                                        //     ),
                                        //   ),
                                        //   // In this example, the date is formatted manually. You can
                                        //   // use the intl package to format the value based on the
                                        //   // user's locale settings.
                                        //   child: Text(
                                        //     '${date.month}-${date.day}-${date.year}',
                                        //     style: const TextStyle(
                                        //       fontSize: 22.0,
                                        //     ),
                                        //   ),
                                        // ),
                                        SizedBox(width: 20,),
                                        InkWell(
                                          onTap:()
                                          {
                                            _showDialog(
                                              CupertinoDatePicker(
                                                initialDateTime: time,
                                                mode: CupertinoDatePickerMode.time,
                                                use24hFormat: true,
                                                // This is called when the user changes the time.
                                                onDateTimeChanged: (DateTime newTime) {
                                                  setState(() => time = newTime);
                                                },
                                              ),
                                            );
                                          },
                                          child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            color: CustomColors.AppbarColor1
                                          ),
                                          child: Center(child: Text('Time',style: TextStyle(color: Colors.white),)),
                                          height: 30,width: 60,),
                                        ),
                                        Text(
                                          '${time.hour}:${time.minute}',
                                          style: const TextStyle(
                                            fontSize: 22.0,
                                          ),
                                        ),
                                    ],)
                                  ],),
                        ),
                      ),
                                ),
                              ),
                              SizedBox(height: 20,),
                              // Image.asset('assets/images/requestinfoimage.png',height: 150,width:400,),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20,),
                CustomAppBtn(height: 50,width: 300,title: 'Post Request',onPress: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context)=> RideScreen()));
                },),
                const SizedBox(height: 20,),
              ]),
        ),
      ),
    );
  }

 }
