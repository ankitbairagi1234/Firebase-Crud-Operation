import 'package:connection_app/Helper/CustomColors.dart';
import 'package:connection_app/Presentation/AppBar/CustomAppBar.dart';
import 'package:connection_app/Presentation/requestinfo_screen.dart';
import 'package:connection_app/Presentation/ridescreen.dart';
import 'package:connection_app/Presentation/story.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> party = [
    {'image': "assets/images/homeScreenimage1.png",
      'text': 'Name Of Tiffin Centre',
      'address':'E-9, Sai Plaza, under Andhra Bank Main Rd, H I G L I G, '
          'LIG Colony, Indore,',
      "time":"10:00 Am To 7:00 Pm" ,
    },
    {'image': "assets/images/homeScreenimage1.png",
      'text': 'Name Of Tiffin Centre',
      'address':'E-9, Sai Plaza, under Andhra Bank Main Rd, H I G L I G, '
          'LIG Colony, Indore,',
      "time":"10:00 Am To 7:00 Pm",
    },
    {'image': "assets/images/homeScreenimage1.png",
      'text': 'Name Of Tiffin Centre',
      'address':'E-9, Sai Plaza, under Andhra Bank Main Rd, H I G L I G, '
          'LIG Colony, Indore,',
      "time":"10:00 Am To 7:00 Pm",
    },
    // {"image": "assets/images/2022.png", "name":"Party night" ,"location":"assets/images/location.png","address": "Palsia, Indore"},
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: getDrawer(),
        body: Column(
          children: [
            CustomAppBar(),
            SizedBox(height: 20,),
            Container(
              height: 55,
              width: MediaQuery.of(context).size.width / 1.1,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: CustomColors.TransparentColor),
              child: TextFormField(
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  suffixIcon: Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Icon(
                      Icons.search,
                    ),
                  ),
                  contentPadding: EdgeInsets.only(top: 15, left: 5),
                  border: InputBorder.none,
                  hintText: "Explore Now",
                ),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.only(right: 235.0),
              child: Text('Popular Near you',style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.bold),),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18.0,left: 15),
              child: Container(
                height: 170,
                child: ListView.builder(
                  // physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: false,
                    scrollDirection: Axis.horizontal,
                    itemCount: party.length,
                    itemBuilder: (context, index){
                      return Card(
                        color: CustomColors.TransparentColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          //mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Image.asset(party[index]['image'], height: 100,width: 220,fit: BoxFit.fill,),
                            Text(party[index]['text'],style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                            Text(party[index][ 'address'],style: TextStyle(fontSize: 7),),
                            Text(party[index]['time'],style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                            //SizedBox(height: 20,),
                            //Text('2000'),
                          ],
                        ),
                      );
                    }),
              ),
            ),
          ],
        ),
      ),
    );
  }
  getDrawer() {
    // print("checking user pic ${userPic}");
    return Drawer(
      backgroundColor:  Color(0xFF010759),
      child: ListView(
        padding: EdgeInsets.all(10),
        children: <Widget>[
          ListTile(
            leading: Image.asset("assets/drawerassets/homeicon.png",scale: 4.2,),
            title: const Text(' Home ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/rideicon.png",scale: 4.2,),
            title: const Text('Rides',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/abouticon.png",scale: 4.2,),
            title: const Text(' My Profile ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RequestinfoScreens()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/acomondationicon4.png",scale: 4.2,),
            title: const Text(' Accommodation ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => StoryDemo()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/tiffinicon5.png",scale: 4.2,),
            title: const Text(' Tiffin Center  ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RideScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/festival6.png",scale: 4.2,),
            title: const Text(' Festivals & Events ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/holyplace7.png",scale: 4.2,),
            title: const Text(' Holy Places ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/indianstore8.png",scale: 4.2,),
            title: const Text(' Indian Store ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/videoicon.png",scale: 4.2,),
            title: const Text(' Video ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/abouticon.png",scale: 4.2,),
            title: const Text(' About ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),
          ListTile(
            leading: Image.asset("assets/drawerassets/settingicon.png",scale: 4.2,),
            title: const Text(' Settings ',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              );
            },
          ),

          ListTile(
            leading: Image.asset("assets/drawerassets/logout.png",scale: 4.2,),

            title: const Text('LogOut',style: TextStyle(color: CustomColors.primaryColor),),
            onTap: () {
              // Alert(
              //   context: context,
              //   title: "Log out",
              //   desc: "Are you sure you want to log out?",
              //   style: AlertStyle(
              //       isCloseButton: false,
              //       descStyle:
              //       TextStyle(fontFamily: "MuliRegular", fontSize: 15),
              //       titleStyle: TextStyle(fontFamily: "MuliRegular")),
              //   buttons: [
              //     DialogButton(
              //       child: Text(
              //         "OK",
              //         style: TextStyle(
              //             color: Colors.white,
              //             fontSize: 16,
              //             fontFamily: "MuliRegular"),
              //       ),
              //       onPressed: () async {
              //         setState(() {
              //           userID = '';
              //           userEmail = '';
              //           userMobile = '';
              //           likedProduct = [];
              //           likedService = [];
              //         });
              //         // signOutGoogle();
              //         //signOutFacebook();
              //         preferences!
              //             .remove(SharedPreferencesKey.LOGGED_IN_USERRDATA)
              //             .then((_) {
              //           Navigator.of(context).pushAndRemoveUntil(
              //             MaterialPageRoute(
              //               builder: (context) => Welcome2(),
              //             ),
              //                 (Route<dynamic> route) => false,
              //           );
              //         });
              //
              //         Navigator.of(context, rootNavigator: true).pop();
              //       },
              //       color: backgroundblack,
              //       // color: Color.fromRGBO(0, 179, 134, 1.0),
              //     ),
              //     DialogButton(
              //       child: Text(
              //         "Cancel",
              //         style: TextStyle(
              //             color: Colors.white,
              //             fontSize: 16,
              //             fontFamily: "MuliRegular"),
              //       ),
              //       onPressed: () {
              //         Navigator.of(context, rootNavigator: true).pop();
              //       },
              //       color: backgroundblack,
              //       // gradient: LinearGradient(colors: [
              //       //   Color.fromRGBO(116, 116, 191, 1.0),
              //       //   Color.fromRGBO(52, 138, 199, 1.0)
              //       // ]),
              //     ),
              //   ],
              // ).show();
            },
          ),
        ],
      ),
    );
  }
}
