import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Helper/CustomColors.dart';

class RideScreen extends StatefulWidget {
  const RideScreen({Key? key}) : super(key: key);

  @override
  State<RideScreen> createState() => _RideScreenState();
}

class _RideScreenState extends State<RideScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height/3,
                      decoration: BoxDecoration(image: DecorationImage(image: AssetImage('assets/images/requestinfoimage.png'),fit:BoxFit.fill)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.dehaze_rounded,color: Colors.white,),
                                SizedBox(width: 250,),
                                Icon(Icons.chat_rounded,color: Colors.white,),
                                SizedBox(width: 25,),
                                Icon(Icons.notifications_active_outlined,color: Colors.white,),
                              ],
                            ),
                          ),
                          Text('Ride',style: TextStyle(
                              color: CustomColors.primaryColor,fontSize: 25,fontWeight: FontWeight.w500),),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 120.0),
                      child: Container(
                        height: 500,
                        child: Card(
                          elevation: 4,
                          child: Column(
                            children: [
                              InkWell(
                                onTap: () {
                                  // Navigator.push(context, MaterialPageRoute(builder: (context)=>RideScreen2()));
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 10.0,left: 10,right: 10),
                                  child: Container(
                                    // height: 135,
                                    // width: 420,
                                    child: Card(
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                        elevation: 4,
                                        child: Row(
                                          children: [
                                            Image.asset('assets/images/travlinguser.png',height: 100,width:80,),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(height: 20,),
                                                Row(children: [
                                                  Padding(
                                                    padding: const EdgeInsets.only(top: 18.0),
                                                    child: Text("Alex Hotel Inore MP"),
                                                  ),
                                                ],),
                                                Container(
                                                  width: 170,
                                                  child: Divider(
                                                    thickness: 1.2,
                                                    indent: 20,
                                                  ),
                                                ),
                                               // Divider(),
                                                Text("Sunshine Hotel,indore"),
                                                SizedBox(height: 10,),
                                                Row(
                                                  children: [
                                                    Text("Passenger: Ankit ",style: TextStyle(color: Colors.red),),
                                                    Text(" Ride Time : 2;00",style: TextStyle(color: Colors.red),),
                                                  ],
                                                ),
                                              ],),
                                            Padding(
                                              padding: const EdgeInsets.only(bottom: 18.0),
                                              child: Image.asset('assets/images/travlingbag.png',height: 80,width: 49,),
                                            ),
                                          ],
                                        )),
                                  ),
                                ),
                              ),
                              SizedBox(height: 20,),
                              // Image.asset('assets/images/requestinfoimage.png',height: 150,width:400,),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Padding(
                    //   padding: const EdgeInsets.only(top: 178,left: 50),
                    //   child: Text('I Am Looking For \n Ride',style: TextStyle(
                    //       color: CustomColors.primaryColor,fontSize: 20,fontWeight: FontWeight.w700),),
                    // ),
                    // Padding(
                    //   padding: const EdgeInsets.only(top: 348.0,left: 50),
                    //   child: Text('I Am Looking For\n Passenger',style: TextStyle(
                    //       color: CustomColors.primaryColor,fontSize: 20,fontWeight: FontWeight.w700),),
                    // ),
                  ],
                ),
              ]),
        ),
      ),
    );
  }
}
